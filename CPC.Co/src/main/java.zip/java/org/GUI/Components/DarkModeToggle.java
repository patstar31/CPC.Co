package org.GUI.Components;

import org.GUI.Theme.ThemeManager;
import static org.GUI.utils.UIConstants.*;
import javax.swing.*;
import java.awt.*;

public class DarkModeToggle extends JPanel {
    private final JToggleButton toggleButton;

    public DarkModeToggle() {
        setLayout(new FlowLayout(FlowLayout.RIGHT));
        setOpaque(false);

        toggleButton = new JToggleButton();
        updateButtonAppearance();

        toggleButton.addActionListener(e -> {
            ThemeManager.getInstance().toggleDarkMode();
            updateButtonAppearance();
        });

        ThemeManager.getInstance().addListener(this::updateButtonAppearance);
        add(toggleButton);
    }

    private void updateButtonAppearance() {
        boolean isDarkMode = ThemeManager.getInstance().isDarkMode();

        if (isDarkMode) {
            toggleButton.setText("☀️");
            toggleButton.setToolTipText("Switch to Light Mode");
        } else {
            toggleButton.setText("🌙");
            toggleButton.setToolTipText("Switch to Dark Mode");
        }

        toggleButton.setBackground(ThemeManager.getInstance().getComponentBgColor());
        toggleButton.setForeground(ThemeManager.getInstance().getTextPrimary());
        toggleButton.setFont(FONT_BUTTON);
        toggleButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        toggleButton.setFocusPainted(false);
    }
}