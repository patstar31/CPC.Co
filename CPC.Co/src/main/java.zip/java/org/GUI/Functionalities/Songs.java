package org.GUI.Functionalities;

public class Songs {
    public String songName;
    public String songArtist;
    public String songPhotoCover;
}