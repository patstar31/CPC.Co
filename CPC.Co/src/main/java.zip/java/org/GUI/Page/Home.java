package org.GUI.Page;

import org.GUI.Components.GradientPanel;
import org.GUI.Components.RoundedPanel;
import org.GUI.Components.ShadowPanel;
import org.GUI.Functionalities.Songs;
import org.GUI.Theme.ThemeListener;
import org.GUI.Theme.ThemeManager;
import org.GUI.utils.SongLoader;
import static org.GUI.utils.UIConstants.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class Home extends JPanel implements ThemeListener {
    private final JPanel cardPanel;
    private GradientPanel gradientPanel;
    private RoundedPanel searchBar;
    private JTextField searchField;
    private RoundedPanel allSongsPanel;
    private JLabel allSongsLabel;
    private JLabel recentlyPlayedLabel;
    private JPanel navBar;
    private final List<RoundedPanel> songBoxes = new ArrayList<>();
    private final List<JLabel> songTitleLabels = new ArrayList<>();
    private final List<JLabel> songArtistLabels = new ArrayList<>();
    private final JPanel gridPanel;

    public Home(JPanel cardPanel) {
        this.cardPanel = cardPanel;

        // --- Basic UI Setup ---
        RoundedPanel phonePanel = new RoundedPanel(PHONE_PANEL_CORNER_RADIUS, Color.BLACK);
        phonePanel.setLayout(new BorderLayout());
        phonePanel.setPreferredSize(PHONE_PANEL_DIMENSION);
        phonePanel.setMaximumSize(PHONE_PANEL_DIMENSION);
        phonePanel.setMinimumSize(PHONE_PANEL_DIMENSION);

        gradientPanel = new GradientPanel(Color.BLACK, Color.GRAY);
        gradientPanel.setLayout(new BorderLayout());
        phonePanel.add(gradientPanel, BorderLayout.CENTER);

        JPanel topContentPanel = new JPanel();
        topContentPanel.setOpaque(false);
        topContentPanel.setLayout(new BoxLayout(topContentPanel, BoxLayout.Y_AXIS));
        gradientPanel.add(topContentPanel, BorderLayout.NORTH);

        JPanel topSearchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topSearchPanel.setOpaque(false);
        topSearchPanel.setBorder(BorderFactory.createEmptyBorder(18, 0, 6, 0));
        searchBar = new RoundedPanel(CARD_CORNER_RADIUS, Color.WHITE);
        searchBar.setLayout(new BorderLayout(10, 0));
        searchBar.setPreferredSize(SEARCH_BAR_DIMENSION);
        JLabel searchIcon = new JLabel("🔍");
        searchIcon.setFont(FONT_SUBTITLE);
        searchIcon.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        searchBar.add(searchIcon, BorderLayout.WEST);
        searchField = new JTextField("Search for songs, artists, and more...");
        searchField.setBorder(BorderFactory.createEmptyBorder());
        searchField.setFont(FONT_SEARCH_FIELD);
        searchBar.add(searchField, BorderLayout.CENTER);
        topSearchPanel.add(searchBar);
        topContentPanel.add(topSearchPanel);

        JPanel allSongsContainer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        allSongsContainer.setOpaque(false);
        allSongsContainer.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        allSongsPanel = new RoundedPanel(CARD_CORNER_RADIUS, Color.PINK);
        allSongsPanel.setLayout(new GridBagLayout());
        allSongsPanel.setPreferredSize(CARD_DIMENSION_LARGE);
        allSongsLabel = new JLabel("All Songs");
        allSongsLabel.setFont(FONT_TITLE);
        allSongsPanel.add(allSongsLabel);
        allSongsPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ((CardLayout) (cardPanel.getLayout())).show(cardPanel, "AllSongs");
            }
        });
        allSongsContainer.add(allSongsPanel);
        topContentPanel.add(allSongsContainer);

        JPanel recentlyPlayedLabelContainer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        recentlyPlayedLabelContainer.setOpaque(false);
        recentlyPlayedLabelContainer.setBorder(BorderFactory.createEmptyBorder(2, 35, 10, 0));
        recentlyPlayedLabel = new JLabel("Recently Played");
        recentlyPlayedLabel.setFont(FONT_SUBTITLE);
        recentlyPlayedLabelContainer.add(recentlyPlayedLabel);
        topContentPanel.add(recentlyPlayedLabelContainer);
        
        JPanel gridContainer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        gridContainer.setOpaque(false);
        
        gridPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        gridPanel.setOpaque(false);
        
        populateRecentlyPlayed();
        
        gridContainer.add(gridPanel);
        topContentPanel.add(gridContainer);
        
        navBar = new JPanel();
        gradientPanel.add(navBar, BorderLayout.SOUTH);

        ShadowPanel shadowPanel = new ShadowPanel(phonePanel);
        this.setLayout(new GridBagLayout());
        this.setOpaque(false);
        this.add(shadowPanel);

        ThemeManager.getInstance().addListener(this);
        updateTheme();
    }

    private void populateRecentlyPlayed() {
        gridPanel.removeAll();
        songBoxes.clear();
        songTitleLabels.clear();
        songArtistLabels.clear();
        
        List<Songs> songs = SongLoader.loadSongs("/songs.txt");
        
        for (Songs song : songs) {
            gridPanel.add(createSongBox(song));
        }

        this.revalidate();
        this.repaint();
    }
    
    @Override
    public void themeChanged() {
        updateTheme();
    }

    private void updateTheme() {
        gradientPanel.setColors(ThemeManager.getInstance().getGradientBg1(), ThemeManager.getInstance().getGradientBg2());
        searchBar.setBackground(ThemeManager.getInstance().getComponentBgColor());
        searchField.setBackground(ThemeManager.getInstance().getComponentBgColor());
        searchField.setForeground(ThemeManager.getInstance().getTextSecondary());
        searchField.setCaretColor(ThemeManager.getInstance().getTextPrimary());
        allSongsPanel.setBackground(ThemeManager.getInstance().getAccentColor());
        allSongsLabel.setForeground(ThemeManager.getInstance().getTextPrimary());
        recentlyPlayedLabel.setForeground(ThemeManager.getInstance().getTextPrimary());

        for (RoundedPanel box : songBoxes) {
            box.setBackground(ThemeManager.getInstance().getComponentBgColor());
        }
        for (JLabel title : songTitleLabels) {
            title.setForeground(ThemeManager.getInstance().getTextPrimary());
        }
        for (JLabel artist : songArtistLabels) {
            artist.setForeground(ThemeManager.getInstance().getTextSecondary());
        }

        gradientPanel.remove(navBar);
        navBar = createBottomNavBar();
        gradientPanel.add(navBar, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    /**
     * Creates a single song panel and makes it clickable.
     */
    private JPanel createSongBox(Songs song) {
        RoundedPanel songPanel = new RoundedPanel(SMALL_CORNER_RADIUS, Color.GRAY);
        songPanel.setLayout(new BorderLayout(5, 0));
        songPanel.setPreferredSize(new Dimension(170, 85));
        songBoxes.add(songPanel);

        // --- NEW: Add a click listener to the panel ---
        songPanel.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Change cursor on hover
        songPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // When clicked, show the "Now Playing" pop-up
                showNowPlayingFrame(song);
            }
        });

        try {
            ImageIcon originalIcon = new ImageIcon(getClass().getResource(song.songPhotoCover));
            Image scaledImage = originalIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            imageLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0));
            songPanel.add(imageLabel, BorderLayout.WEST);
        } catch (Exception e) {
            System.err.println("Could not load image: " + song.songPhotoCover);
        }

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 5));

        JLabel titleLabel = new JLabel(song.songName);
        titleLabel.setFont(new Font(FONT_PRIMARY, Font.BOLD, 14));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        songTitleLabels.add(titleLabel);

        JLabel artistLabel = new JLabel(song.songArtist);
        artistLabel.setFont(FONT_ARTIST);
        artistLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        songArtistLabels.add(artistLabel);

        textPanel.add(titleLabel);
        textPanel.add(artistLabel);
        songPanel.add(textPanel, BorderLayout.CENTER);

        return songPanel;
    }

    /**
     * --- NEW: A helper method to create and show the "Now Playing" JFrame ---
     */
    private void showNowPlayingFrame(Songs song) {
        // Create the new frame
        JFrame nowPlayingFrame = new JFrame("Now Playing");
        nowPlayingFrame.setSize(300, 150);
        nowPlayingFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Only closes the pop-up
        nowPlayingFrame.setLocationRelativeTo(this); // Center it over the main window
        nowPlayingFrame.setResizable(false);

        // Create a panel for the content with a theme-aware background
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(ThemeManager.getInstance().getGradientBg1());

        // Create the "Playing music" label
        JLabel label = new JLabel("<html><center>Playing music...<br><b>" + song.songName + "</b> by " + song.songArtist + "</center></html>");
        label.setForeground(ThemeManager.getInstance().getTextPrimary()); // Theme-aware text color
        label.setFont(FONT_BUTTON); // Use a constant for the font
        panel.add(label);

        nowPlayingFrame.add(panel);
        nowPlayingFrame.setVisible(true); // Show the frame
    }
    
    private JPanel createBottomNavBar() {
        JPanel newNavBar = new JPanel(new GridLayout(1, 3));
        newNavBar.setOpaque(false);
        newNavBar.setPreferredSize(new Dimension(0, 70));
        newNavBar.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));

        Color activeColor = ThemeManager.getInstance().getAccentColor();
        Color inactiveColor = ThemeManager.getInstance().getTextPrimary();

        JPanel homeItem = createNavItem(ICON_HOME, "Home", activeColor, true);
        JPanel libraryItem = createNavItem(ICON_LIBRARY, "Library", inactiveColor, false);
        libraryItem.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { ((CardLayout) (cardPanel.getLayout())).show(cardPanel, "Library"); }
        });
        JPanel accountItem = createNavItem(ICON_ACCOUNT, "Account", inactiveColor, false);
        accountItem.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { ((CardLayout) (cardPanel.getLayout())).show(cardPanel, "Account"); }
        });

        newNavBar.add(homeItem);
        newNavBar.add(libraryItem);
        newNavBar.add(accountItem);
        return newNavBar;
    }

    private JPanel createNavItem(String iconText, String labelText, Color color, boolean isActive) {
        JPanel itemPanel = new JPanel();
        itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));
        itemPanel.setOpaque(false);
        JLabel iconLabel = new JLabel(iconText);
        iconLabel.setFont(FONT_ICON_NAV);
        iconLabel.setForeground(color);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel textLabel = new JLabel(labelText);
        textLabel.setFont(isActive ? FONT_NAV_BAR_BOLD : FONT_NAV_BAR);
        textLabel.setForeground(color);
        textLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        itemPanel.add(iconLabel);
        itemPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        itemPanel.add(textLabel);
        return itemPanel;
    }
}